/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapps;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Dillon
 */
public class QuickTest {

    /**
     * Main method
     *
     * @param args not used
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        Scanner sc1 = new Scanner(System.in);
        boolean run = true;
        while (run) {
            System.out.println("");
            System.out.println("Press 0 to sort by QuickSort/Insertion Combo.");
            System.out.println("Press 1 to sort by QuickSort.");
            System.out.println("Press 2 to exit.");
            switch (sc1.nextInt()) {
                case 0:
                    //Combined QuickSort with InsertionSort
                    System.out.println("Enter the max size/input for the array");
                    int maxSize = sc1.nextInt();
                    CombineQuickSortInsertionSort comboArray = new CombineQuickSortInsertionSort(maxSize);
                    for (int j = 0; j < maxSize; j++) {
                        long n = (int) (java.lang.Math.random() * maxSize);
                        comboArray.insert(n);
                    }
                    comboArray.print();
                    long startTime = System.nanoTime();
                    comboArray.quickSort();
                    long endTime = System.nanoTime();
                    comboArray.print();
                    //Time information
                    System.out.println("");
                    System.out.println("Time in nanoseconds: " + (endTime - startTime));
                    System.out.println("Time in milliseconds: "
                            + (endTime - startTime) / 1000000);
                    System.out.println("Time in seconds: " + (endTime - startTime) / 100000000);
                    break;
                case 1:
                    //Normal QuickSort
                    System.out.println("Enter the max size/input for the array");
                    maxSize = sc1.nextInt();
                    MyQuickSort quickArray = new MyQuickSort(maxSize);
                    for (int j = 0; j < maxSize; j++) {
                        int n = (int) (java.lang.Math.random() * maxSize);
                        quickArray.insert(n);
                    }
                    quickArray.print();
                    startTime = System.nanoTime();
                    quickArray.sort();
                    endTime = System.nanoTime();
                    quickArray.print();
                    //Time information
                    System.out.println("");
                    System.out.println("Time in nanoseconds: " + (endTime - startTime));
                    System.out.println("Time in milliseconds: "
                            + (endTime - startTime) / 1000000);
                    System.out.println("Time in seconds: " + (endTime - startTime) / 100000000);
                    break;
                case 2:
                    System.exit(0);
            }
        }
        //exit program if reach here
        run = false;

    }

    /**
     * QuickSort with Insertion Sort Class
     */
    public static class CombineQuickSortInsertionSort {

        //data array
        private long[] data;
        //length of array
        private int length;
        
        private int CUTOFF=10;

        /**
         * Constructor
         *
         * @param max the max value of the array
         */
        public CombineQuickSortInsertionSort(int max) {
            data = new long[max];
            length = 0;
        }

        /**
         * Inserts values into the array
         *
         * @param value the value to insert
         */
        public void insert(long value) {
            data[length] = value;
            length++;
        }

        /**
         * Prints the array as a visual representation
         */
        public void print() {
            System.out.print("Data:");
            for (int j = 0; j < length; j++) {
                System.out.print(data[j] + " ");
            }
            System.out.println("");
        }

        /**
         * QuickSort method using recursion
         */
        public void quickSort() {
            recQuickSort(0, length - 1);
        }

        /**
         * Recursive QuickSort method to sort the sub arrays
         *
         * @param left the left position to start sorting
         * @param right the right position to end sorting
         */
        public void recQuickSort(int left, int right) {
            int size = right - left + 1;
            if (size < CUTOFF) {
                insertionSort(left, right);
            } else {
                long median = medianOf3(left, right);
                int partition = partitionIt(left, right, median);
                recQuickSort(left, partition-1);
                recQuickSort(partition + 1, right);
            }
        }

        /**
         * Partitioning based on medians of 3
         *
         * @param left
         * @param right
         * @return the sub array partitioned
         */
        public long medianOf3(int left, int right) {
            int center = (left + right) / 2;
            // order left & center
            if (data[left] > data[center]) {
                swap(left, center);
            }
            // order left & right
            if (data[left] > data[right]) {
                swap(left, right);
            }
            // order center & right
            if (data[center] > data[right]) {
                swap(center, right);
            }

            swap(center, right - 1);
            return data[right - 1];
        }

        /**
         * Swap method to exchange values
         *
         * @param d1 value 1
         * @param d2 value 2
         */
        public void swap(int d1, int d2) {
            long temp = data[d1];
            data[d1] = data[d2];
            data[d2] = temp;
        }

        /**
         * Partition method to section off sub arrays to be sorted
         *
         * @param left the left position to start
         * @param right the right position to end
         * @param pivot the pivot point
         * @return the left pointer pivot location
         */
        public int partitionIt(int left, int right, long pivot) {
            int leftPtr = left; // right of first elem
            int rightPtr = right - 1; // left of pivot
            while (true) {
                //find bigger
                while (data[++leftPtr] < pivot)
        ;
                //find smaller
                while (data[--rightPtr] > pivot)
        ;
                if (leftPtr >= rightPtr) // if pointers cross, partition done
                {
                    break;
                } else {
                    swap(leftPtr, rightPtr);
                }
            }
            swap(leftPtr, right - 1); // restore pivot
            return leftPtr; // return pivot location
        }

        /**
         * Insertion sort method to sort sub arrays less than 10
         *
         * @param left the left position to start
         * @param right the right position to end
         */
        public void insertionSort(int left, int right) {
            int in, out;
            //  sorted on left of out
            for (out = left + 1; out <= right; out++) {
                long temp = data[out]; // remove marked item
                in = out; // start shifts at out
                // until one is smaller,
                while (in > left && data[in - 1] >= temp) {
                    data[in] = data[in - 1]; // shift item to right
                    --in; // go left one position
                }
                data[in] = temp; // insert marked item
            }
        }
    } //end of other quicksort/insertion class

    /**
     * QuickSort class without insertion
     */
    public static class MyQuickSort {

        private int data[];
        private int length;

        /**
         * Constructor
         *
         * @param max the max size of the array
         */
        public MyQuickSort(int max) {
            data = new int[max];
            length = 0;
        }

        /**
         * Inserts values into the array
         *
         * @param value value to insert
         */
        public void insert(int value) {
            data[length] = value;
            length++;
        }

        /**
         * Prints the array
         */
        public void print() {
            System.out.print("Data:");
            for (int j = 0; j < length; j++) {
                System.out.print(data[j] + " ");
            }
            System.out.println("");
        }

        /**
         * Sort method for QuickSort using recursive calls
         */
        public void sort() {

            if (data == null || data.length == 0) {
                return;
            }
            this.data = data;
            length = data.length;
            quickSort(0, length - 1);
        }

        /**
         * Recursive QuickSort method
         *
         * @param lowerIndex the left end to sort
         * @param higherIndex the right/higher end to end at
         */
        public void quickSort(int lowerIndex, int higherIndex) {

            int i = lowerIndex;
            int j = higherIndex;
            // calculate pivot number, I am taking pivot as middle index number
            int pivot = data[lowerIndex + (higherIndex - lowerIndex) / 2];
            // Divide into two arrays
            while (i <= j) {
                /**
                 * In each iteration, we will identify a number from left side
                 * which is greater then the pivot value, and also we will
                 * identify a number from right side which is less then the
                 * pivot value. Once the search is done, then we exchange both
                 * numbers.
                 */
                while (data[i] < pivot) {
                    i++;
                }
                while (data[j] > pivot) {
                    j--;
                }
                if (i <= j) {
                    exchangeNumbers(i, j);
                    //move index to next position on both sides
                    i++;
                    j--;
                }
            }
            // call quickSort() method recursively
            if (lowerIndex < j) {
                quickSort(lowerIndex, j);
            }
            if (i < higherIndex) {
                quickSort(i, higherIndex);
            }
        }

        /**
         * Method to swap number values when being called
         *
         * @param i the first number to swap
         * @param j the second number to swap
         */
        private void exchangeNumbers(int i, int j) {
            int temp = data[i];
            data[i] = data[j];
            data[j] = temp;
        }
    } //end of QuickSort class

} //end of file
