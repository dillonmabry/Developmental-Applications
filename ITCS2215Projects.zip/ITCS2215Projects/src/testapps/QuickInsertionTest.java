/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapps;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Dillon Mabry
 */
public class QuickInsertionTest {

    /**
     * Main method
     *
     * @param args unused
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        //combo sort 20 times
        Scanner sc1 = new Scanner(System.in);
        
        boolean condition = true;
        while (condition) {
        System.out.println("Press 0 to sort by QuickSort/Insertion combo.");
        System.out.println("Press 1 to sort by QuickSort.");
        System.out.println("Press 2 to exit.");
            switch (sc1.nextInt()) {
                case 0:
                    System.out.println("Enter the name of the file to save "
                            + "test timings.");
                    String filename = sc1.next();
                    try (BufferedWriter out = new BufferedWriter(new FileWriter(filename, true))) {
                        System.out.println("Enter the input size.");
                        int maxSize = sc1.nextInt();
                        System.out.println("Enter the number of times you wish to test.");
                        int runTimes = sc1.nextInt();
                        for (int i = 0; i < runTimes; i++) {
                            QuickTest.CombineQuickSortInsertionSort comboArray = new QuickTest.CombineQuickSortInsertionSort(maxSize);
                            for (int j = 0; j < maxSize; j++) {
                                long n = (int) (java.lang.Math.random() * maxSize);
                                comboArray.insert(n);
                            }
                            comboArray.print();
                            long startTime = System.nanoTime();
                            comboArray.quickSort();
                            long endTime = System.nanoTime();
                            comboArray.print();
                            //Time information
                            System.out.println("");
                            System.out.println("Time in nanoseconds: " + (endTime - startTime));
                            System.out.println("Time in milliseconds: "
                                    + (endTime - startTime) / 1000000);
                            int msTime = (int) ((endTime - startTime) / 1000000);
                            out.write(msTime + "");
                            out.newLine();
                            System.out.println("Time in seconds: " + (endTime - startTime) / 100000000);
                        }
                    } catch (IOException e) {
                        System.out.println("I/O exception, exiting....");
                        System.exit(0);
                    }
                    break;
                case 1:
                    System.out.println("Enter the name of the file to save "
                            + "test timings.");
                    String filename2 = sc1.next();
                    try (BufferedWriter out2 = new BufferedWriter(new FileWriter(filename2, true))) {
                        System.out.println("Enter the input size.");
                        int maxSize2 = sc1.nextInt();
                        System.out.println("Enter the number of times you wish to test.");
                        int runTimes2 = sc1.nextInt();
                        for (int i = 0; i < runTimes2; i++) {
                            QuickTest.MyQuickSort quickArray = new QuickTest.MyQuickSort(maxSize2);
                            for (int j = 0; j < maxSize2; j++) {
                                long n = (int) (java.lang.Math.random() * maxSize2);
                                quickArray.insert((int) n);
                            }
                            quickArray.print();
                            long startTime2 = System.nanoTime();
                            quickArray.sort();
                            long endTime2 = System.nanoTime();
                            quickArray.print();
                            //Time information
                            System.out.println("");
                            System.out.println("Time in nanoseconds: " + (endTime2 - startTime2));
                            System.out.println("Time in milliseconds: "
                                    + (endTime2 - startTime2) / 1000000);
                            int msTime = (int) ((endTime2 - startTime2) / 1000000);
                            out2.write(msTime + "");
                            out2.newLine();
                            System.out.println("Time in seconds: " + (endTime2 - startTime2) / 100000000);
                        }
                    } catch (IOException e) {
                        System.out.println("I/O exception, exiting....");
                        System.exit(0);
                    }
                    break;
                case 2: 
                    System.out.println("Exiting....");
                    System.exit(0);
            }
        }
         condition=false;
    } //end of main

} //end of file
