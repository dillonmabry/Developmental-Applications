/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapps;

import java.io.IOException;

/**
 *
 * @author Dillon
 */
public class Matrix2DSearch {

    //2-D matrix initialized
    private static int[][] valueMatrix = {{1, 2, 3, 4, 5}, {6, 7, 8, 9, 10},
    {11, 12, 13, 14, 15}, {16, 17, 18, 19, 20}, {21, 22, 23, 24, 25}};

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        for (int i = 0; i < valueMatrix.length; i++) {
            for (int j = 0; j < valueMatrix.length; j++) {
                if (valueMatrix[i][j] != 0) {
                    System.out.print(valueMatrix[i][j] + " ");
                }
            }
            System.out.println("");
        }

        search(valueMatrix, 18);
    }

    /**
     * Method to search for a given integer key in a 2-D matrix of
     * sorted positive integers in increasing order
     * @param matrix the 2-D matrix to search
     * @param x the search key
     * @return the index of the searched key if found, if not return false
     */
    public static int search(int[][] matrix, int x) {
        //set indexes for searching
        int i = 0, j = matrix.length - 1;  
        while (i < matrix.length && j >= 0) {    
            if (matrix[i][j] == x) {
                System.out.println("\n Found at: " + i + " " + j);
                return 1;
            } 
            //if the search key is less than the current index
            if (matrix[i][j] > x) {
                j--;
            } 
            //if the search key is greater than the current index
            else {
                i++;
            }
        }
        //counter has not found element after scan
        System.out.println("Element not found");
        return 0;
    }

}
