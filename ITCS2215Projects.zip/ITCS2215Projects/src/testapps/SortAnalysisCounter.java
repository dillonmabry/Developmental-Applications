/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import javax.swing.JFileChooser;

/**
 *
 * @author Dillon
 */
public class SortAnalysisCounter {

    private static final int[] array = new int[100];
    private static int temp = 0;
    static int counter = 0;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        readFile();
        insertionSort(array);

    }

    /**
     * Method to brute force search a char array and return index of specified
     * char search character
     *
     * @param T the char array to search
     * @param P the character to find index for
     * @return the index number of the desired character
     */
    public static int bruteForceStringMatch(char[] T, char[] P) {
        for (int i = 0; i < T.length; i++) {
            int j = 0;
            while (j < P.length && P[j] == T[i + j]) {
                j = j++;
                return i;
            }
            if (j == P.length) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Method to pick a file from a given input
     *
     * @return the File to be used
     * @throws FileNotFoundException if file is not found
     */
    public static File pickFile() throws FileNotFoundException {

        /* creates new JFileChooser and approves the file through 
         scanner input */
        JFileChooser chooser1 = new JFileChooser();
        java.io.File thisFile = null;
        if (chooser1.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            thisFile = chooser1.getSelectedFile();
            Scanner sc1 = new Scanner(thisFile);
        } else {
            System.out.println("No file selected");
        }
        return thisFile;
    }

    /**
     * Method to read the file that is given and add each input word to the
     * ArrayOrderedList to be printed out
     *
     * @throws FileNotFoundException if file is not found
     * @throws IOException if an input/output error occurs
     */
    public static void readFile() throws FileNotFoundException, IOException {
        try {
            String filename = pickFile().toString();
            FileInputStream fileInput = new FileInputStream(filename);
            int i;
            while (fileInput.available() > 0) {
                i = (int) fileInput.read();
                for (int j = temp; j < array.length; j++) {
                    array[j] = i;
                }
                temp++;
            }

            fileInput.close();

        } catch (FileNotFoundException e) {
            System.out.println("File is not found exiting");
            System.exit(0);
        }
    }

    public static void insertionSort(int[] list) {
        long startTime = System.nanoTime();
        int comps = 0, swaps = 0;

        for (int i = 1; i < list.length; i++) {

            int j = i;
            // compare i with sorted elements and insert it
            // sorted elements: [0..i-1]
            while (j > 0 && list[j] < list[j - 1]) {

                int temp = list[j];
                list[j] = list[j - 1];
                list[j - 1] = temp;

                swaps++;
                comps++;  // loop condition true

                j--;
            }
            comps++; // checking loop condition when false
        }
        System.out.println("Comparisons: " + comps + "Swaps: " + swaps);
        long endTime = System.nanoTime();
        long durationNano = ((endTime - startTime));
        double durationSecond = ((endTime - startTime) / 1000000);
        System.out.println(durationSecond);
    }


    
} //end of class
