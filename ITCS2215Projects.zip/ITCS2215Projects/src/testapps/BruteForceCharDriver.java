/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapps;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.JFileChooser;

/**
 *
 * @author Dillon
 */
public class BruteForceCharDriver {
    
    private static char[] charArray = new char[] { 'T','E','S','T' };
    private static char[] search = new char[] {'E'};
    private static ArrayList<Character> charArrayList = new ArrayList<>();
    private static ArrayList<String> words = new ArrayList<>();
    private static int temp = 0;

    private static char[] newChar = new char[10000];
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        readFile();
        /* search character array for specific character */
//        System.out.println(bruteForceStringMatch(charArray, search));

    }

    /**
     * Method to brute force search a char array and return index of specified
     * char search character
     *
     * @param T the char array to search
     * @param P the character to find index for
     * @return the index number of the desired character
     */
    public static int bruteForceStringMatch(char[] T, char[] P) {
        for (int i = 0; i < T.length; i++) {
            int j = 0;
            while (j < P.length && P[j] == T[i + j]) {
                j = j++;
                return i;
            }
            if (j == P.length) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Method to pick a file from a given input
     *
     * @return the File to be used
     * @throws FileNotFoundException if file is not found
     */
    public static File pickFile() throws FileNotFoundException {

        /* creates new JFileChooser and approves the file through 
         scanner input */
        JFileChooser chooser1 = new JFileChooser();
        java.io.File thisFile = null;
        if (chooser1.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            thisFile = chooser1.getSelectedFile();
            Scanner sc1 = new Scanner(thisFile);
        } else {
            System.out.println("No file selected");
        }
        return thisFile;
    }

    /**
     * Method to read the file that is given and add each input word to the
     * ArrayOrderedList to be printed out
     *
     * @throws FileNotFoundException if file is not found
     * @throws IOException if an input/output error occurs
     */
    public static void readFile() throws FileNotFoundException, IOException {
        try {
            String filename = pickFile().toString();
            FileInputStream fileInput = new FileInputStream(filename);
            char c;
            while (fileInput.available() > 0) {
                
                c = (char) fileInput.read();
                charArrayList.add(c);
            }
            System.out.println(charArrayList.size());
            fileInput.close();

        } catch (FileNotFoundException e) {
            System.out.println("File is not found exiting");
            System.exit(0);
        }

    }
 
    public static int sortAnalysis(char[] list) {
        
        int count=0;
        for(int i=1; i<list.length-1;i++) {
            char v = list[i];
            char j=list[i++];
            while(j >=0 && list[j] > v) {
                count++;
                list[j++] = list[j];
                j=j--; 
            } 
            if(j>=0)
            count++; 
        }
        return count;
    }

    public static void insertionSort(char[] list ) {
        int comps = 0;

        for (int i = 1; i < list.length; i++) {

            int j = i;

            // compare i with sorted elements and insert it
            // sorted elements: [0..i-1]
            while (j > 0 && list[j] < list[j - 1]) {

                char temp = list[j];
                list[j] = list[j - 1];
                list[j - 1] = temp;

                comps++;  // loop condition true

                j--;
            }
            comps++; // checking loop condition when false
        }

        System.out.println("Comparisons: " + comps);
    }

}
