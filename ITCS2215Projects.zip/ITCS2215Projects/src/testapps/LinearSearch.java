/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFileChooser;

/**
 *
 * @author Dillon
 */
public class LinearSearch {

    private static char[] charArray = new char[47];
    private static String words = "This is my word list to search with my key";
    private static char[] searchArray = new char[]{'E', 'E'};
    private static int temp = 0;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        readFile();
        linearSearch(charArray, searchArray);
//        
//        String key = "search";
//        int j,i;
//        int counter=0;
//        i=j=0;
//        
//        for(i=0; i< words.length();i++) {
//            j=i;
//            if(j> key.length() -1) 
//                j=0;
//            if (key.charAt(j)==words.charAt(i)) {
//                counter++;
//                int temp;
//                if(i==0)
//                    temp=0;
//                else
//                    temp=i-1;
//                System.out.println(words.charAt(temp));
//                
//                if(words.charAt(temp)==' ' || temp==0) {
//                    int tempCount;
//                    int keyCount=j;
//                    for(tempCount=i; tempCount < words.length(); tempCount++) {
//                        if(keyCount>= key.length() && words.charAt(tempCount)!=' ') {
//                            System.out.println("word not found");
//                            counter++;
//                            break;
//                        } else if(keyCount>= key.length() && words.charAt(tempCount)==' ') {
//                            System.out.println("Word found");
//                            counter++;
//                            break;
//                        }
//                        if(key.charAt(keyCount)==words.charAt(tempCount)) {
//                            keyCount++;
//                            counter++;
//                        }
//                    }
//                } else {
//                    System.out.println("at the start of a word");
//                    counter++;
//                }
//            }
//        }
//        System.out.println(counter);

    } //end of main method

    public static void linearSearch(char[] T, char[] search) {
        int counter = 0;
        int i = 0;

        for (int j = 0; j < search.length; j++) {
            for (i = 0; i < T.length; i++) {
                if (T[i] == search[j]) /* Searching element is present */ {
                    System.out.println(search[j] + " is present at location " + (i + 1) + ".");
                    counter++;
                    System.out.println("Counter is " + counter);
                    break;
                } else {
                    counter++;
                }
            }
        }
        if (i == 0) /* Searching element is absent */ {
            System.out.println(search + " is not present in array.");
        }
    }

    public static int sortAnalysis(int[] T) {
        int count = 0;
        for (int i = 1; i < T.length - 1; i++) {
            int v = T[i];
            int j = T[i - 1];
            while (j >= 0 && T[j] > v) {
                count = count++;
                T[j + 1] = T[j];
                j = T[j - 1];
            }
            if (j >= 0) {
                count = count + 1;
            }
            T[j + 1] = v;
        }
        return count;
    }

    /**
     * Method to pick a file from a given input
     *
     * @return the File to be used
     * @throws FileNotFoundException if file is not found
     */
    public static File pickFile() throws FileNotFoundException {

        /* creates new JFileChooser and approves the file through 
         scanner input */
        JFileChooser chooser1 = new JFileChooser();
        java.io.File thisFile = null;
        if (chooser1.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            thisFile = chooser1.getSelectedFile();
            Scanner sc1 = new Scanner(thisFile);
        } else {
            System.out.println("No file selected");
        }
        return thisFile;
    }

    /**
     * Method to read the file that is given and add each input word to the
     * ArrayOrderedList to be printed out
     *
     * @throws FileNotFoundException if file is not found
     * @throws IOException if an input/output error occurs
     */
    public static void readFile() throws FileNotFoundException, IOException {
        try {
            String filename = pickFile().toString();
            FileInputStream fileInput = new FileInputStream(filename);
            char c;
            while (fileInput.available() > 0) {
                c = (char) fileInput.read();
                for (int i = temp; i < charArray.length; i++) {
                    charArray[i] = c;
                }
                temp++;
            }
            fileInput.close();
            System.out.println(charArray);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found exiting");
            System.exit(0);
        }
    }

}
