/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapps;

import java.io.IOException;
import java.util.Random;

/**
 *
 * @author Dillon
 */
public class QuickSort {

    /**
     * Main method
     *
     * @param args not used
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        
        int maxSize = 10;
        long startTime = System.nanoTime();
        MyQuickSort arr = new MyQuickSort(maxSize);
        long endTime = System.nanoTime();
        arr.populateArray();
        arr.printArray();
        arr.quickSort(0, maxSize - 1);
        arr.printArray();
        System.out.println("");
        System.out.println("Time in nanoseconds: " + (endTime - startTime));
        System.out.println("Time in milliseconds: "
                + (endTime - startTime) / 1000000);
        System.out.println("Time in seconds: " + (endTime - startTime) / 100000000);
    }

    /**
     * QuickSort
     */
    public static class MyQuickSort {

        private int array[];
        private int length;

        /**
         * Constructor
         * @param maxSize the maximum size of array to sort
         */
        public MyQuickSort(int maxSize) {
            array = new int[maxSize];
            length = 0;
        }

        /**
         * Method to add numbers to the array randomly 
         * in successive order
         */
        public void populateArray() {
            Random rand = new Random();
            for (int i = 0; i < array.length; i++) {
                int r = rand.nextInt(i + 1);
                array[i] = array[r];
                array[r] = i + 1;
            }
        }

        /**
         * Method to print array
         *
         */
        public void printArray() {
            System.out.println("");
            for (int i = 0; i < array.length; i++) {
                System.out.print(array[i] + " ");
            }
        }

        public void sort(int[] inputArr) {

            if (inputArr == null || inputArr.length == 0) {
                return;
            }
            this.array = inputArr;
            length = inputArr.length;
            quickSort(0, length - 1);
        }

        public void quickSort(int lowerIndex, int higherIndex) {

            int i = lowerIndex;
            int j = higherIndex;
            //start pivot point (middle number)
            int pivot = array[lowerIndex + (higherIndex - lowerIndex) / 2];
            //split into 2 sub arrays
            while (i <= j) {
                /*
                 Identify number less than pivot value and number
                 greater than pivot value. Then swap the numbers ordering
                 successfully
                 */
                while (array[i] < pivot) {
                    i++;
                }
                while (array[j] > pivot) {
                    j--;
                }
                if (i <= j) {
                    swap(i, j);
                    //start at next position and continue
                    i++;
                    j--;
                }
            }
            // call quickSort() method recursively
            if (lowerIndex < j) {
                quickSort(lowerIndex, j);
            }
            if (i < higherIndex) {
                quickSort(i, higherIndex);
            }
        }

        private void swap(int i, int j) {
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }

    } //end of class

} //end of file

